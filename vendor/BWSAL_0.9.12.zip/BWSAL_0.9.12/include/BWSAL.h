#pragma once
#include <BWAPI.h>
#include <Arbitrator.h>
extern Arbitrator::Arbitrator<BWAPI::Unit*,double>* TheArbitrator;