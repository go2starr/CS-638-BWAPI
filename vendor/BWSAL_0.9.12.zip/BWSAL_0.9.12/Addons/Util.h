#include <RectangleArray.h>
#include <map>
void log(const char* text, ...);
std::map<int, int> computeAssignments(Util::RectangleArray< double> &cost);